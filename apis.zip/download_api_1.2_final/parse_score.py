with open('score.txt') as fp:
   line = fp.readline()
print(str(line))
