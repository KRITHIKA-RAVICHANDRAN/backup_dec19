bash ready.sh
bash see_score_command.sh
bash remove.sh
rm remove_file.txt
