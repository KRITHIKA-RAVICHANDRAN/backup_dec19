for f in $(cat remove_file.txt) ; do 
  rm "$f"
done
echo "removed"


