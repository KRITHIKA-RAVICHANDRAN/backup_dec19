cat file.txt|tail -n 3
