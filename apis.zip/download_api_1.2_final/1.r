z <-"25-12-2016"
z <- as.Date(z, format = "%d-%m-%Y")
z