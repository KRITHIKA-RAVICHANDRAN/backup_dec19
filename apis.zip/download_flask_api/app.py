from flask import Flask,render_template,url_for,request
import pandas as pd 
import download_zip
import copy_ap
import os

app = Flask(__name__)

@app.route('/')
def home():
	
	return render_template('home.html')

@app.route('/predict',methods=['POST'])
def predict():
	
	
	if request.method == 'POST':
		
		link=request.form['field1']
		repo=request.form['field2']
		download_zip.downloadlink(link)
		copy_ap.copy_answer(repo)
		ans=os.system("bash run_script.sh")
		print('ans')
		print(ans)
		with open('score.txt') as fp:
   			line = fp.readline()
		print(str(line))
		result=str(line)
		# if ans==0:
		# 	result="successful"
		# else:
		# 	result="fail"
	return render_template('end.html',ans=result)
		



if __name__ == '__main__':
	app.run(debug=True)

