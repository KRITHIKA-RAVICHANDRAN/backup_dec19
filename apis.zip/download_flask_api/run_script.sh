
bash ready.sh
bash see_score_command.sh>score.txt
bash remove.sh
rm remove_file.txt
rm file.json

