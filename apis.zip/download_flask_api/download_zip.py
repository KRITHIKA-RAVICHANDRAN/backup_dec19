import requests
def downloadlink(link):
	r=requests.get(link)
	# r=requests.get('https://istreet-proctor.s3.amazonaws.com/fullstack/questions/v1/57h8h8n5ad1/stack/fo2nkjhq2jl/ab744bb15661390a97ce5ca657ec49b3.zip')
	import zipfile
	import io
	z = zipfile.ZipFile(io.BytesIO(r.content))
	rm_list=z.namelist()
	with open('remove_file.txt', 'w') as f:
	    for item in rm_list:
	        f.write("%s\n" % item)
	z.extractall()


