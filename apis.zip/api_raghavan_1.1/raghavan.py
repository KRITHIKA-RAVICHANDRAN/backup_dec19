# import Workbook
from openpyxl import Workbook
import xlrd 
# import load_workbook
from openpyxl import load_workbook
# create Workbook object
wb=Workbook()
# set file path
filepath="demo.xlsx"
# save workbook 
wb.save(filepath)
# load demo.xlsx 
wb=load_workbook(filepath)
# select demo.xlsx
sheet=wb.active
# set value for cell A1=1
# set value for cel2=2

sheet.cell(1,1).value = 2
sheet.cell(2,1).value = 2

# save workbook 

wb.save(filepath)
wb = xlrd.open_workbook(filepath) 
sheet = wb.sheet_by_index(0) 
print(sheet.nrows)

word=["hai","hello"]
print(word[1])