from flask import Flask,render_template,url_for,request
import pandas as pd 
import pickle

# import Workbook
from openpyxl import Workbook
import xlrd

# import load_workbook
from openpyxl import load_workbook


app = Flask(__name__)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['POST'])
def predict():
	
	
	#set file path
	filepath="review_comments.xlsx"
	
	if request.method == 'POST':
		message = request.form['message']
		num=request.form['ID']
		name=request.form['name']
		arr=[num,name,message]
		print(message)

		wb = xlrd.open_workbook(filepath) 
		sheet = wb.sheet_by_index(0) 
		row=sheet.nrows+1
		# load demo.xlsx 
		wb=load_workbook(filepath)
		# select demo.xlsx
		sheet=wb.active
		index=0
		for i in range(1,4):
			sheet.cell(row,i).value = arr[index]
			index=index+1
		# save workbook 
		wb.save(filepath)
		val=num+" comment added successfully"
	return render_template('back.html',prediction = val)
		



if __name__ == '__main__':
	app.run(debug=True)

