from flask import Flask,render_template,url_for,request
import pandas as pd 
import pickle

# import Workbook
from openpyxl import Workbook
import xlrd

# import load_workbook
from openpyxl import load_workbook
import sample


app = Flask(__name__)

@app.route('/')
def home():
	a=sample.my_function()
	b=sample.my_function1()
	return render_template('home.html',vall=a,val3=b)

@app.route('/predict',methods=['POST'])
def predict():
	
	b=sample.update_counter_file()
	#set file path
	filepath="comments.xlsx"
	
	if request.method == 'POST':
		message = request.form['comment']
		num=request.form['field1']
		name=request.form['field2']
		arr=[num,name,message]
		print(message)

		wb = xlrd.open_workbook(filepath) 
		sheet = wb.sheet_by_index(0) 
		row=sheet.nrows+1
		# load demo.xlsx 
		wb=load_workbook(filepath)
		# select demo.xlsx
		sheet=wb.active
		index=0
		for i in range(1,4):
			sheet.cell(row,i).value = arr[index]
			index=index+1
		# save workbook 
		wb.save(filepath)
		val=str(num)+" comment added successfully"
		print(val)
	return render_template('back.html',prediction1 = val)

@app.route('/updatenew',methods=['POST'])
def updatenew():
	
	
	#set file path
	filepath="comments.xlsx"
	
	if request.method == 'POST':
		message = request.form['comment']
		# num=int(request.form['field1'])
		name=request.form['field2']
		dropd=request.form['colours']
		num=int(dropd)
		arr=[num,name,message]
		print(message)
		print('colours')
		print(dropd)

		

	df = pd.read_excel('/home/krithika/Desktop/api_raghavan_1.2/comments.xlsx', sheet_name=0) # can also index sheet by name or fetch all sheets
	mylist = df['ID'].tolist()
	print(mylist)
	row=1
	update_row=0
	for i in mylist:
		row=row+1
		if num==i:
			update_row=row
			break
	wb = xlrd.open_workbook(filepath) 
	sheet = wb.sheet_by_index(0) 
	
	# load demo.xlsx 
	wb=load_workbook(filepath)
	# select demo.xlsx
	sheet=wb.active
	index=0
	for i in range(1,4):
		sheet.cell(update_row,i).value = arr[index]
		index=index+1
	# save workbook 
	wb.save(filepath)
	val=str(num)+" updated successfully"
	return render_template('back1.html',prediction=val)
   		
@app.route('/update')
def update():
		df = pd.read_excel('/home/krithika/Desktop/api_raghavan_1.2/comments.xlsx', sheet_name=0) # can also index sheet by name or fetch all sheets
		mylist = df['ID'].tolist()
		mylist.pop(0)
		colours = mylist
		print(colours)
		return render_template('update.html',colours=colours)

	
	

if __name__ == '__main__':
	app.run(host="localhost", port=8000, debug=True)

