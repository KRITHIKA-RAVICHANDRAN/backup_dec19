import urllib.request
import json
from openpyxl import load_workbook
import xlrd
loc="/home/krithika/Desktop/api_raghavan_1.2/input/Courses.xlsx"
loc1="/home/krithika/Desktop/api_raghavan_1.2/input/counter.txt"
  

	
def read_excel():
	wb = load_workbook(loc) 
	sheet = wb.get_sheet_by_name('Sheet1')
	return sheet

def read_text():
	file1 = open(loc1,"r+")  
	return int(file1.read())

def update_counter_file():
	file1 = open(loc1,"r")  
	value=int(file1.read())

	value=value+1
	file1.close()
	file1 = open(loc1,"w")  
	file1.write(str(value))
	print(value)
	file1.close()



def my_function():
	sheet=read_excel()
	rows=sheet.max_row
	#print(rows)
	col_num=0
	list_with_values=[]
	for cell in sheet[1]:
		col_num=col_num+1
		if cell.value=="Question_ID Hackerrank":
			print(col_num)
			break

	row_num=read_text()
	print(row_num)
	#print(row_num)
	#print(col_num)
	cell_obj=sheet.cell(row_num,col_num)
	print((cell_obj.value))
	return(cell_obj.value)

def my_function1():
	sheet=read_excel()
	rows=sheet.max_row
	#print(rows)
	col_num=0
	list_with_values=[]
	for cell in sheet[1]:
		col_num=col_num+1
		if cell.value=="Card name":
			print(col_num)
			break

	row_num=read_text()
	print(row_num)
	#print(row_num)
	#print(col_num)
	cell_obj=sheet.cell(row_num,col_num)
	print((cell_obj.value))
	return(cell_obj.value)



	  
	 
  
# Finally, close the Excel file 
# via the close() method. 
	workbook.close() 
#------------------iterate column hackerrank---------
# for i in range(2,rows+1):
# 	cell_obj=sheet.cell(i,col_num)
# 	print((cell_obj.value))
#------------------------------------------
# for col in sheet.iter_cols(values_only=True):
#         for value in col:
#             if isinstance(value, str) and 'Question_ID Hackerrank' in value:
#                 print(col)
# print(col)


# #Writing
# from openpyxl import load_workbook
# wb = load_workbook(loc)    if isinstance(value, str) and 'Question_ID Hackerrank' in cell.value:

# ws = wb.get_sheet_by_name("Links")

# for i in range(0,5): 
# 	j=i+1
# 	link=sheet.cell_value(i,0)
# 	print(link)
# 	links_stripped=link.strip()
# 	id1=split(links_stripped)
# 	url=get_url(id1)
# 	json_data=url_to_json(url)
# 	if(len(json_data["items"])!=0):
# 		Duration="Duration: "+json_data["items"][0]["contentDetails"]["duration"]+" "
# 		Title="Title: "+json_data["items"][0]["snippet"]["title"]
# 		write_obj=Duration+Title
# 		print(write_obj)
# 		ws.cell(j,2).value=write_obj
# 	else:
# 		write_obj="Video not available"
# 		print(write_obj)
# 		ws.cell(j,2).value=write_obj

# wb.save('YT_Links.xlsx') 



