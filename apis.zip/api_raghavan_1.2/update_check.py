
			

import pandas as pd

df = pd.read_excel('/home/krithika/Desktop/api_raghavan_1.2/comments.xlsx', sheet_name=0) # can also index sheet by name or fetch all sheets
mylist = df['ID'].tolist()
row=1
for i in mylist:
	row=row+1
	if 737652==i:
		print(row)
