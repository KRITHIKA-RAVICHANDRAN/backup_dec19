

function myFunction() {
var fs = require("fs");
console.log("Going to write into existing file");

fs.readFile('/home/krithika/Desktop/api_raghavan_1.2/input/counter.txt', function (err, data) {
      if (err) {
         return console.error(err);
      }
      var a1=parseInt(data)
      a1=a1+1
      console.log(a1)
      fs.writeFile('/home/krithika/Desktop/api_raghavan_1.2/input/counter.txt',a1,function(err) {
        if (err) {
      return console.error(err);
   }
   console.log("Data written successfully!");
   // Read the newly written file and print all of its content on the console
   
});
   });

}
