import requests
r=requests.get('https://istreet-proctor.s3.amazonaws.com/fullstack/questions/v1/1c7ddf7dt55/stack/791fg1nmpp5/8edf0ea7f9ee0ca41b475d241f91c63c.zip')
# r=requests.get('https://istreet-proctor.s3.amazonaws.com/fullstack/questions/v1/57h8h8n5ad1/stack/fo2nkjhq2jl/ab744bb15661390a97ce5ca657ec49b3.zip')
import zipfile
import io
z = zipfile.ZipFile(io.BytesIO(r.content))
z.extractall()

