x<- c("yes", "no", "yes", "maybe")
levels(factor(x))