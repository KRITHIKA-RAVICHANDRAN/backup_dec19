sudo bash see_install_command.sh
bash ready.sh
bash see_score_command.sh
