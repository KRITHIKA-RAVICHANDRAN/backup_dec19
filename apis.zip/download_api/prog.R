#Write your code here 


x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))
x<- c("yes", "no", "yes", "maybe")

levels(factor(x))