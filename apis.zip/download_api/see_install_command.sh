sudo bash .install.sh
