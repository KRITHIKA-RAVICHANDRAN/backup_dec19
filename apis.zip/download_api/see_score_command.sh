bash .score.sh
