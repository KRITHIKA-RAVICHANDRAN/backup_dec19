with open("1.r") as f:
    with open("prog.R", "a") as f1:
        for line in f:
            f1.write("\n"+line)
print('copied')
