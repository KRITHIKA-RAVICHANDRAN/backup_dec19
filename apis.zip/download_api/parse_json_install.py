import json
with open('file.json') as f:
  data = json.load(f)
# Output: {'name': 'Bob', 'languages': ['English', 'Fench']}
#print(data['configuration']['ide_config']['project_menu']['run'])
var=data['configuration']['ide_config']['project_menu']['install']
print("sudo"+" "+var)
