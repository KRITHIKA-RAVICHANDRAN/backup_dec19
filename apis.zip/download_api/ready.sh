python copy.py

python -c 'import sys, yaml, json; json.dump(yaml.load(sys.stdin), sys.stdout, indent=4)' < hackerrank.yml > file.json
python parse_json_install.py>see_install_command.sh
python parse_json_score.py>see_score_command.sh
